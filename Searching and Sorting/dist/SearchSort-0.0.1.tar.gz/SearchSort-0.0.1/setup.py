
from setuptools import setup

setup(name = 'SearchSort',
version = '0.0.1',
description = 'A package that contains searching and sorting algorithms',
url = '#',
author = 'Suyash Srivastava',
author_email = 'suyashmaths@gmail.com',
license = 'humblesoul',
packages = ['SearchSort'],
install_requires = [],
zip_safe = False)